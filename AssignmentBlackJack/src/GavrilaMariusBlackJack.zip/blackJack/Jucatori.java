package blackJack;

public enum Jucatori {

	
	PLAYER,OPONENT;
	
}
