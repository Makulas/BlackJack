package blackJack;

public enum Valoare {
	
	DOI,TREI,PATRU,CINCI,SASE,SAPTE,OPT,NOUA,ZECE,VALET,DAMA,REGE,AS;

}
