package blackJack;

public enum Suita {
	
	TREFLA,
	NEAGRA,
	ROMB,
	INIMA;

}
